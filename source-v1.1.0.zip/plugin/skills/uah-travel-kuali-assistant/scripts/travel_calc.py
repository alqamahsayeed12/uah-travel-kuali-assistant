#!/usr/bin/env python3
"""Deterministic calculations using supplied evidence-backed inputs. No live prices or policy decisions."""
import argparse
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import json
from pathlib import Path
import sys

def dec(value, negative=False):
    if value is None or isinstance(value, bool):
        raise ValueError('Missing/invalid numeric value')
    try:
        d=Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError('Invalid number') from exc
    if not d.is_finite() or (d < 0 and not negative):
        raise ValueError('Number must be finite and nonnegative')
    return d

def usd(value):
    return str(value.quantize(Decimal('.01'), rounding=ROUND_HALF_UP))

def source_for(country, region):
    if country != 'US':
        return 'State'
    if region in {'AK','HI','PR','GU','VI','AS','MP'}:
        return 'DTMO'
    return 'GSA'

def reimbursement_branch(country, region):
    return 'Alabama rules: verify actual/per-diem eligibility' if country == 'US' and region == 'AL' else 'Verify UAH adoption of destination benchmark'

def kuali_process(approval_date=None):
    if approval_date and date.fromisoformat(approval_date) < date(2026,10,1):
        return 'Legacy manual exception permitted; verify applicability'
    return 'Current consolidated Kuali; verify live fields/routing'

def effective(day, rates, locality, source):
    found=[r for r in rates if r['locality']==locality and r['source']==source and date.fromisoformat(r['start']) <= day <= date.fromisoformat(r['end'])]
    if len(found)!=1 or not found[0].get('citation'):
        raise ValueError('Missing, overlapping or uncited effective rate for '+day.isoformat())
    return found[0]

def hotel(data):
    start,end = date.fromisoformat(data['checkin']),date.fromisoformat(data['checkout'])
    if end<=start:
        raise ValueError('Checkout must follow checkin')
    nights=data['nights']
    if len(nights)!=(end-start).days or len({n['date'] for n in nights})!=len(nights):
        raise ValueError('Missing/duplicate nights')
    lookup={n['date']:n for n in nights}
    tolerance=dec(data.get('tolerance',50)); total=Decimal(0);rows=[]
    for i in range((end-start).days):
        day=start+timedelta(days=i); n=lookup[day.isoformat()]
        r=effective(day,data['rates'],data['locality'],data['source'])
        benchmark=dec(r['lodging']); price=dec(n['base']); tax=dec(n['tax']); fee=dec(n['fees']); transit=dec(n['transport'])
        lower=max(Decimal(0),benchmark-tolerance); upper=benchmark+tolerance
        category='Within or below benchmark' if price<=benchmark else 'Within tolerance above benchmark' if price<=upper else 'Outside preferred range'
        amount=price+tax+fee+transit;total+=amount
        rows.append({'date':day.isoformat(),'benchmark':usd(benchmark),'lower':usd(lower),'upper':usd(upper),'base':usd(price),'delta':usd(price-benchmark),'classification':category,'in_discovery_band':lower<=price<=upper,'hotel_and_transport':usd(amount),'citation':r['citation']})
    return {'nights':rows,'hotel_and_transport_total':usd(total),'reimbursement_authorized':False}

def mileage(data):
    total=Decimal(0);rows=[]
    for leg in data['legs']:
        day=date.fromisoformat(leg['date']);rate=effective(day,data['rates'],data['locality'],'UAH')
        value=dec(leg['miles'])*dec(rate['per_mile']);total+=value
        rows.append({'date':leg['date'],'amount':usd(value),'citation':rate['citation']})
    return {'legs':rows,'total':usd(total),'eligibility_verified':False}

def meals(data):
    # Method must be explicitly verified; this utility intentionally has no UAH default.
    if data.get('method_verified') is not True or not data.get('policy_citation') or data.get('policy_conflict_unresolved',True):
        raise ValueError('Resolve applicable UAH meal policy and cite method before calculation')
    if data.get('method')!='per_diem':
        raise ValueError('Only explicitly verified per_diem supported; actual expense method requires reconciliation')
    order=data['deduction_order']
    if order not in {'deduct_then_factor','factor_then_deduct'}:
        raise ValueError('Explicit verified deduction order required')
    total=Decimal(0);rows=[]; seen=set()
    for item in data['days']:
        day=date.fromisoformat(item['date'])
        if day in seen: raise ValueError('Duplicate meal day')
        seen.add(day)
        gross=dec(item['meals'])+dec(item['incidentals'])
        deduction=sum((dec(v) for v in item['provided_meals']),Decimal(0))
        factor=dec(item['factor'])
        if factor>1 or deduction>gross:
            raise ValueError('Invalid day factor/deductions')
        value=max(Decimal(0),(gross-deduction)*factor if order=='deduct_then_factor' else gross*factor-deduction)
        value=value.quantize(Decimal('.01'),rounding=ROUND_HALF_UP);total+=value
        rows.append({'date':item['date'],'amount':usd(value)})
    return {'days':rows,'total':usd(total),'policy_citation':data['policy_citation']}

def scenarios(data):
    rows=[]
    for scenario in data['scenarios']:
        ids=set();total=Decimal(0);unknown=[];paid=Decimal(0)
        for c in scenario['components']:
            if c['id'] in ids:
                raise ValueError('Duplicate component ID')
            ids.add(c['id'])
            if c['payer'] not in {'traveler','UAH','P-Card','sponsor'}: raise ValueError('Unknown payer')
            if c.get('amount') is None:
                unknown.append(c['id']);continue
            amount=dec(c['amount']);total+=amount
            if c['payer'] in {'UAH','P-Card'}: paid+=amount
        rows.append({'name':scenario['name'],'known_economic_cost':usd(total),'complete':not unknown,'unknown':unknown,'UAH_direct_paid':usd(paid),'other_outlay':usd(total-paid),'hours':scenario.get('hours'),'hypothetical_ceiling':scenario.get('ceiling'),'policy_allowance':'Requires independent policy evaluation'})
    complete=[r for r in rows if r['complete']]
    minimum=min((dec(r['known_economic_cost']) for r in complete),default=None)
    # Never rank incomplete scenarios as cheaper.
    for r in rows:
        r['difference_from_lowest_complete']=usd(dec(r['known_economic_cost'])-minimum) if r['complete'] and minimum is not None else None
    return {'scenarios':rows,'ranking_complete':len(complete)==len(rows)}

def reconcile(data):
    ids=set();fingerprints={}; duplicates=[];rows=[];actual=Decimal(0);outlay=Decimal(0);known_reimburse=Decimal(0);unknown=[];estimate=Decimal(0)
    currency=data['currency']
    for e in data['expenses']:
        if e['id'] in ids: raise ValueError('Duplicate transaction ID: '+e['id'])
        ids.add(e['id'])
        date.fromisoformat(e['date'])
        if e['payer'] not in {'traveler','UAH','P-Card','sponsor'}: raise ValueError('Unknown payer')
        if e['currency']!=currency: raise ValueError('Convert currency with documented FX before reconciliation')
        if e['state'] not in {'posted','hold','estimate','void'}: raise ValueError('Unknown expense state')
        amount=dec(e['amount']); estimate+=dec(e.get('authorized_estimate',0))
        key=(e['date'],' '.join(e['merchant'].casefold().split()),str(amount.normalize()),currency)
        duplicate_of=fingerprints.get(key)
        if e['state']=='posted': fingerprints[key]=e['id']
        if duplicate_of and e['state']=='posted': duplicates.append([duplicate_of,e['id']])
        incurred=e['state']=='posted'
        evidence=e.get('proof_of_payment') is True and bool(e.get('receipt')) and e.get('original_reviewed') is True
        allowance=e.get('eligible_amount');payable=None
        if incurred:
            actual+=amount
            if e['payer']=='traveler': outlay+=amount
            if duplicate_of:
                unknown.append(e['id']+': potential duplicate requires review')
            if evidence and e.get('policy_verified') is True and e.get('policy_citation') and allowance is not None and not duplicate_of:
                allowed=dec(allowance)
                if allowed>amount: raise ValueError('Eligible amount exceeds actual charge')
                payable=allowed if e['payer']=='traveler' else Decimal(0)
                known_reimburse+=payable
            else: unknown.append(e['id']+': missing evidence or policy determination')
        rows.append({'id':e['id'],'actual':usd(amount) if incurred else None,'payer':e['payer'],'potentially_reimbursable':usd(payable) if payable is not None else None,'evidence_status':'reviewed original and payment' if evidence else 'incomplete','duplicate_of':duplicate_of,'state':e['state']})
    return {'rows':rows,'authorized_estimate_total':usd(estimate),'recorded_actual_total_before_duplicate_resolution':usd(actual),'actual_minus_estimate':usd(actual-estimate),'traveler_outlay_before_duplicate_resolution':usd(outlay),'known_potential_reimbursement':usd(known_reimburse),'reimbursement_total':usd(known_reimburse) if not unknown else None,'unresolved':unknown,'possible_duplicates':duplicates,'final_determination':'UAH Business Services'}

def run(data):
    mode=data['operation']
    operations={'hotel':hotel,'mileage':mileage,'meals':meals,'scenarios':scenarios,'reconcile':reconcile}
    if mode=='route': return {'benchmark_source':source_for(data['country'],data['region']),'reimbursement_branch':reimbursement_branch(data['country'],data['region']),'kuali_process':kuali_process(data.get('authorization_approved'))}
    if mode not in operations: raise ValueError('Unknown operation')
    return operations[mode](data)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input',type=Path);args=parser.parse_args()
    try:
        print(json.dumps(run(json.loads(args.input.read_text())),indent=2));return 0
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print(json.dumps({'error':str(exc),'result_complete':False}),file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
