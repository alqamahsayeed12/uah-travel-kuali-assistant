"""Evaluate declared routing facts. Does not verify inventory or policy approval."""
import json,sys

def check(route):
    reasons=[]; misses=[]
    connections=route.get('connection_minutes')
    if connections is None: reasons.append('Connection durations unverified')
    elif any(x is None or x < 45 for x in connections): reasons.append('Connection below 45 minutes or unverified')
    if connections is not None and len(connections)>1: misses.append('More than one connection')
    if route.get('overnight') is not False: reasons.append('Overnight travel or overnight status unverified')
    arrival=route.get('arrival_local_time')
    if arrival is None: misses.append('Arrival time unverified')
    elif arrival >= '18:00': misses.append('Arrival not before 6 p.m.')
    departure=route.get('departure_local_time')
    if departure is None: misses.append('Departure time unverified')
    elif departure <= '10:00': misses.append('Departure not after 10 a.m.')
    return {'eligible_for_recommendation':not reasons,'exclusions':reasons,'preference_misses':misses,'institutional_approval':'Not determined'}

if __name__=='__main__':
    print(json.dumps(check(json.load(open(sys.argv[1]))),indent=2))
