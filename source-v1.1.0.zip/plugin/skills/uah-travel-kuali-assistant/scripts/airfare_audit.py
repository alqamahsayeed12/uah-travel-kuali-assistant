#!/usr/bin/env python3
"""Validate reviewed evidence records, not screenshot pixels or institutional compliance."""
import argparse
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import sys

LABELS = ["Lowest-cost fare class identified", "Lowest fare availability screenshot captured",
          "Selected fare and price screenshot captured", "Dates, flights, passengers and settings match",
          "Evidence retained with booking documentation"]
STATUSES = {"available", "sold_out", "unavailable", "not_offered", "absent", "unverified"}

def money(value):
    if isinstance(value, bool) or value is None:
        raise ValueError("Missing or invalid amount")
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError("Invalid amount") from exc
    if not result.is_finite() or result < 0:
        raise ValueError("Amount must be finite and nonnegative")
    return result

def timestamp(value):
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.utcoffset() is None:
        raise ValueError("Timezone offset required")
    return dt

def file_valid(item, base, media=False):
    try:
        path = Path(base) / item["path"]
        data = path.read_bytes()
        if not data or hashlib.sha256(data).hexdigest() != item["sha256"]:
            return False
        return not media or data.startswith((b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"%PDF-"))
    except (KeyError, TypeError, OSError):
        return False

def validate_query(q):
    for k in ("airline", "booking_source", "origin", "destination", "departure_date", "cabin", "fare_filters", "currency", "segments"):
        if not q.get(k):
            raise ValueError("Missing query field: " + k)
    if "return_date" not in q or type(q.get("travelers")) is not int or q["travelers"] <= 0:
        raise ValueError("Query needs return_date (null if one-way) and positive integer travelers")
    from datetime import date
    date.fromisoformat(q["departure_date"])
    if q["return_date"]:
        if date.fromisoformat(q["return_date"]) < date.fromisoformat(q["departure_date"]):
            raise ValueError("Return precedes departure")
    if not isinstance(q["segments"], list):
        raise ValueError("Segments must be a list")
    previous = None
    for segment in q["segments"]:
        for k in ("marketing_carrier", "operating_carrier", "flight_number", "origin", "destination", "departure", "arrival"):
            if not segment.get(k):
                raise ValueError("Incomplete segment: " + k)
        dep, arr = timestamp(segment["departure"]), timestamp(segment["arrival"])
        if dep >= arr or (previous and dep < previous):
            raise ValueError("Impossible segment chronology")
        previous = arr
    if q["segments"][0]["origin"] != q["origin"]:
        raise ValueError("Segment origin differs from query")
    if q["segments"][0]["departure"][:10] != q["departure_date"]:
        raise ValueError("Segment departure differs from query")
    if not any(s["destination"] == q["destination"] for s in q["segments"]):
        raise ValueError("Destination absent from segments")
    if q["return_date"]:
        if q["segments"][-1]["destination"] != q["origin"] or not any(s["origin"] == q["destination"] and s["departure"][:10] == q["return_date"] for s in q["segments"]):
            raise ValueError("Return segments do not match query")

def audit(data, base="."):
    if data.get("schema_version") != 1:
        raise ValueError("Unsupported schema_version")
    phase = data["phase"]
    if phase not in ("prebooking", "reimbursement"):
        raise ValueError("Invalid phase")
    now = timestamp(data["as_of"])
    reference = timestamp(data["booked_at"]) if phase == "reimbursement" else now
    if reference > now:
        raise ValueError("Booking time is in the future")
    window = money(data.get("freshness_minutes", 15)) * 60
    if window <= 0:
        raise ValueError("Freshness window must be positive")
    query = data["query"]
    validate_query(query)
    currency = query["currency"]
    deficits, issues = [], []
    valid = {}
    for e in data.get("evidence", []):
        eid = e["id"]
        if eid in valid:
            raise ValueError("Duplicate evidence ID")
        valid[eid] = False
        try:
            age = Decimal(str((reference - timestamp(e["captured_at"])).total_seconds()))
            ok = (file_valid(e, base, True) and e.get("visually_verified") is True and bool(e.get("reviewer"))
                  and e.get("query") == query and 0 <= age <= window)
        except (ValueError, KeyError, TypeError):
            ok = False
        valid[eid] = ok
        if not ok:
            deficits.append("Invalid, mismatched, unreviewed or noncontemporaneous evidence: " + eid)
    evidence = {e["id"]: e for e in data.get("evidence", [])}
    all_valid = bool(valid) and all(valid.values())
    def kinds_present(kind):
        return any(valid[eid] and kind in evidence[eid].get("kinds", []) for eid in valid)
    def observed(fare):
        for eid in fare.get("evidence_ids", []):
            e = evidence.get(eid, {})
            o = e.get("observations", {}).get(fare["name"], {})
            if not valid.get(eid) or not {"availability", "restrictions"}.issubset(set(e.get("kinds", []))):
                continue
            if o.get("status") != fare["status"] or o.get("currency") != fare["currency"] or o.get("restrictions") != fare.get("restrictions"):
                continue
            if fare["status"] == "available":
                try:
                    if money(o.get("price")) != money(fare["price"]):
                        continue
                except ValueError:
                    continue
            return True
        return False
    fares = data.get("fares", [])
    names = [f["name"] for f in fares]
    if len(set(names)) != len(names):
        raise ValueError("Duplicate fare names")
    fare_ok = bool(fares)
    available = []
    for fare in fares:
        if fare.get("status") not in STATUSES:
            raise ValueError("Invalid fare status")
        if fare.get("currency") != currency:
            fare_ok = False
            deficits.append("Currency mismatch: " + fare["name"])
        if fare["status"] == "available":
            available.append((money(fare["price"]), fare["name"]))
        if not fare.get("restrictions") or not observed(fare):
            fare_ok = False
            deficits.append("Availability/restrictions not evidenced: " + fare["name"])
        if fare["status"] in {"absent", "unverified"}:
            fare_ok = False
            deficits.append("Lower product availability unresolved: " + fare["name"])
            issues.append("Resolve absent/unverified fare with additional evidence or Business Services")
    scope_ok = data.get("all_products_reviewed") is True and data.get("lower_fares_included") is True
    if not scope_ok:
        deficits.append("All fare products and inclusion of lower fares not verified")
    minimum = min(available)[0] if available else None
    selected = data.get("selected", {})
    selection_ok = False
    selected_price = money(selected.get("price"))
    selected_name = selected.get("product")
    for fare in fares:
        if fare["name"] == selected_name and fare["status"] == "available" and money(fare["price"]) == selected_price and fare["currency"] == currency:
            for eid, e in evidence.items():
                es = e.get("selected", {})
                try:
                    if valid[eid] and "selected" in e.get("kinds", []) and es.get("product") == selected_name and money(es.get("price")) == selected_price:
                        selection_ok = True
                except ValueError:
                    pass
    if not selection_ok:
        deficits.append("Selected product and total price not supported by matching original")
    if minimum is not None and selected_price > minimum:
        issues.append("Higher fare selected despite cheaper available product: justify and verify advance approval")
    if data.get("requires_policy_review"):
        issues.append("Explicit policy review flag")
    docs = data.get("documents", [])
    for kind in (["booking_confirmation", "payment_receipt"] if phase == "reimbursement" else []) + (["justification"] if data.get("justification_required") else []) + (["approval"] if data.get("approval_required") else []):
        if not any(d.get("kind") == kind and file_valid(d, base) for d in docs):
            deficits.append("Missing retained document: " + kind)
    if data.get("justification_required") or data.get("approval_required"):
        issues.append("Selection has required justification/approval; institutional review remains necessary")
    purchased = data.get("purchased", {})
    paid = None
    if phase == "reimbursement":
        paid = money(purchased.get("price"))
        if purchased.get("product") != selected_name or paid != selected_price or purchased.get("currency") != currency:
            deficits.append("Purchased fare differs from contemporaneous selected-fare record")
            issues.append("Purchased fare needs historical evidence and policy review")
    checks = [fare_ok and scope_ok and minimum is not None,
              fare_ok and scope_ok and kinds_present("availability"),
              selection_ok,
              all_valid and scope_ok and kinds_present("search") and kinds_present("settings"),
              all_valid and data.get("evidence_retained") is True and data.get("screenshot_confirmation") is True]
    for label, ok in zip(LABELS, checks):
        if not ok:
            deficits.append("Checklist incomplete: " + label)
    complete = all(checks) and not deficits
    upgrade = phase == "reimbursement" and not complete
    if upgrade:
        issues.append("Potential upgrade treatment: missing original evidence; Business Services may request a retrospective comparison")
    difference = None
    comp = data.get("reliable_comparison")
    if phase == "reimbursement" and comp:
        if (comp.get("historical_basis_verified") is True and comp.get("accepted_by_business_services") is True
            and comp.get("basis") and comp.get("currency") == currency and file_valid(comp, base)):
            difference = str(max(Decimal(0), paid - money(comp["amount"])).quantize(Decimal("0.01")))
        else:
            issues.append("Comparison not reliable/accepted; no historical reduction calculated")
    return {"classification": "Evidence incomplete" if not complete else "Policy review required" if issues else "Evidence complete",
            "evidence_status": "Evidence complete" if complete else "Evidence incomplete",
            "policy_review_required": bool(issues), "policy_issues": list(dict.fromkeys(issues)),
            "deficiencies": list(dict.fromkeys(deficits)), "checklist": dict(zip(LABELS, checks)),
            "readiness": str(sum(checks)) + "/5", "lowest_available_products": [n for p, n in available if p == minimum],
            "lowest_available_price": str(minimum) if minimum is not None else None,
            "currency": currency, "traveler_paid": str(paid) if paid is not None else None,
            "potential_upgrade_treatment": upgrade, "potential_reimbursement_difference": difference,
            "potentially_reimbursable_amount": None, "final_determination": "UAH Business Services",
            "purchase_permission": False, "scope": "Reviewed record validation; not screenshot interpretation or compliance certification"}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    try:
        result = audit(json.loads(args.manifest.read_text()), args.manifest.parent)
        print(json.dumps(result, indent=2))
        return 0 if result["classification"] == "Evidence complete" else 2
    except (ValueError, KeyError, TypeError, OSError, IndexError) as exc:
        print(json.dumps({"classification": "Evidence incomplete", "error": str(exc), "purchase_permission": False}), file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
