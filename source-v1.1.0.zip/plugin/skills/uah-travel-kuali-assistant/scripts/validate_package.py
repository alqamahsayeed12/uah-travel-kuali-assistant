#!/usr/bin/env python3
"""Dependency-free package consistency checks; YAML syntax checked separately by a real YAML parser."""
import hashlib
import json
from pathlib import Path
import re
import sys

def main(root):
    root=Path(root); errors=[]
    entry=(root/'SKILL.md').read_text()
    match=re.match(r'^---\n(.*?)\n---\n',entry,re.S)
    if not match: errors.append('Missing frontmatter')
    else:
        fields=dict(line.split(': ',1) for line in match[1].splitlines() if ': ' in line)
        if fields.get('name')!='uah-travel-kuali-assistant': errors.append('Wrong skill name')
        if not fields.get('description') or len(fields['description'])>1024: errors.append('Invalid description')
        if set(fields)-{'name','description','metadata','license','allowed-tools'}: errors.append('Unexpected metadata')
    for name in ['INSTALL.md','agents/openai.yaml','references/master-prompt.md','references/airfare-eight-rules.md','references/policy-version-log.md','references/source-register.json','references/requirements-coverage.md','assets/pre-booking-checklist.md','scripts/airfare_audit.py','scripts/travel_calc.py','tests/test_airfare.py','tests/test_travel.py']:
        if not (root/name).is_file(): errors.append('Missing '+name)
    for p in root.rglob('*.json'):
        try:json.loads(p.read_text())
        except ValueError:errors.append('Invalid JSON '+str(p))
    for p in root.rglob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
            if '://' in target or target.startswith('#'):continue
            if not (p.parent/target.split('#')[0]).exists():errors.append('Broken reference '+str(p)+': '+target)
    if errors:
        print(json.dumps({'valid':False,'errors':errors},indent=2));return 1
    print(json.dumps({'valid':True,'files_checked':sum(p.is_file() and '__pycache__' not in p.parts for p in root.rglob('*')),'master_sha256':hashlib.sha256((root/'references/master-prompt.md').read_bytes()).hexdigest(),'scope':'Consistency and local references; not host registration or policy certification'},indent=2));return 0
if __name__=='__main__':sys.exit(main(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]))
