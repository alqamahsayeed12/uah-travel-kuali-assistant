"""Check declared packet amounts and file hashes; does not read PDF content or certify policy."""
from decimal import Decimal, InvalidOperation
from pathlib import Path
import hashlib, json, sys

def reconcile(data, root):
    errors=[]; total=Decimal('0'); categories=set(); ids=set()
    def amount(value, label):
        try:
            n=Decimal(str(value))
            if not n.is_finite() or n<0: raise InvalidOperation
            return n
        except (InvalidOperation, ValueError):
            errors.append(label+': missing or invalid amount');return None
    for row in data.get('budget',[]):
        category=row.get('category')
        if not category or category in categories: errors.append('Missing or duplicate category')
        categories.add(category)
        q=amount(row.get('quote'),str(category)+' quote');b=amount(row.get('buffer'),str(category)+' buffer');a=amount(row.get('allowance'),str(category)+' allowance')
        if q is not None and b is not None and a is not None and q+b!=a:errors.append(str(category)+': quote plus buffer differs from allowance')
        if a is not None: total+=a
        for c in row.get('cost_ids',[]):
            if c in ids:errors.append('Cost counted twice: '+c)
            ids.add(c)
    if not categories:errors.append('Missing budget')
    for label in ['total','kuali_total','notes_total','combined_total']:
        n=amount(data.get(label),label)
        if n is not None and n!=total:errors.append(label+': total mismatch')
    if data.get('funding_allocations') is not None:
        vals=[amount(v,'funding allocation') for v in data['funding_allocations']]
        if all(v is not None for v in vals) and sum(vals,Decimal('0'))!=total:errors.append('Funding allocation mismatch')
    artifacts=data.get('artifacts',[])
    if not artifacts:errors.append('Missing artifact inventory')
    for a in artifacts:
        path=Path(root)/a['path']; expected=a.get('sha256')
        if not path.is_file():errors.append('Missing artifact: '+a['path']);continue
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if expected!=actual:errors.append('Changed artifact: '+a['path'])
        if a.get('role')=='upload' and a.get('uploaded_sha256')!=actual:errors.append('Upload differs or is unverified: '+a['path'])
        for dep,h in a.get('dependencies',{}).items():
            f=Path(root)/dep
            if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=h:errors.append('Stale dependency: '+dep)
    if data.get('save_verified') is not True:errors.append('Save persistence not verified')
    return {'consistent':not errors,'calculated_total':str(total),'errors':errors,'scope':'Declared values and file hashes only; visually check PDF contents and live form. Not approval or airfare readiness.'}
if __name__=='__main__':
    path=Path(sys.argv[1]);result=reconcile(json.loads(path.read_text()),path.parent);print(json.dumps(result,indent=2));sys.exit(0 if result['consistent'] else 1)
