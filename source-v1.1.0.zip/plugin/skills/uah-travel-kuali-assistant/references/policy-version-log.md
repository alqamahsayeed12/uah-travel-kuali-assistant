# Policy version log

## 1.0.0 — assembled 2026-10-28 (America/Chicago)

- Master: full uploaded master prompt, all 23 sections, preserved in master-prompt.md except personal contact redaction in this colleague edition. Path in the original cloud chat was /mnt/data/Pasted text(20261028-134623).txt; retrieved from that chat's accessible local attachment preview. No private receipts or earlier case advice were bundled.
- Latest user protocol: full eight rules and final validation/checklist from Travel chat, preserved in airfare-eight-rules.md. Retained user-attributed Business Services authority; public independent verification of the entire screenshot protocol remains unavailable.
- Current Kuali announcement: published 2026-09-28, effective 2026-10-01; verified public transition and exception. Legacy manual claims must retain the policy version applicable to authorization approval.
- UAH linked guideline: revised 2023-11-21; P-Card guide: 2013-05-24. Current public links do not eliminate old/new process and meal conflicts. No superseded document was silently promoted to current field-level guidance.
- Kuali authenticated materials, full applicable sponsor/ESSC rules and UA System travel policy: not fully verified; international assistance page verified only for its own scope.
- Government sources: GSA and State landing sources accessible; DTMO denied automated fetch. No destination-specific live rate table or market inventory is bundled.
- Carrier product pages: Delta, American and Southwest reviewed; United accessible only as a JavaScript shell. These are product guidance, never flight-specific availability evidence.

## Append-only entry format

Version | source ID/title | previous version | publication/effective interval | verified date/time | changed rule/section | categories and trips affected | conflict disposition | reviewer | authorized private snapshot or public URL

Preserve historical versions and rate effective intervals. Revisit relevant sources for every new trip and before booking or submission. Update source-register.json without deleting historical entries. Maintenance is on demand; no recurring automation is installed.

## User preference update — 2026-10-28

The user explicitly designated `$HOME/UAH_Travel` as the root for all travel documentation. Resolved path: `$HOME/UAH_Travel`. Updated settings and runtime instructions; this is a storage preference, not institutional policy.

## 2026-10-28 personal customization / 1.0.1
Added latest traveler preferences, 45-minute connection floor, before-6-p.m. arrival preference, no overnight travel, alternative carriers, seven-hour driving review and taxi trip budgeting. Verified official manual Transportation §9; seven hours is not an institutional approval rule. Prior AGU recommendations withdrawn; originals retained.

## 2026-10-28 / 1.0.2
Added explicit registration/additional-cost checklist and user-confirmed first/last travel day per-diem factor of 75%. Provenance is user clarification; this update does not assert independent policy verification.

## 2026-10-28 / 1.0.3
User requested first-draft choices and links, followed by approved-option screenshot capture, plus Uber expected-cost screenshots. New selection-workflow.md overrides initial-research capture timing only. Complete matching airfare evidence remains mandatory before purchase; selection approval is distinct from purchase or institutional approval.

## 2026-10-29 / 1.1.0
User requested incorporation of the full travel discussion and a supplied Kuali submission print. Visually reviewed all 11 pages; extracted only reusable field structure and dated notices. Added native source/date evidence, selected round-trip comparisons, first-person submission writing, budget/attachment synchronization and save/reload verification. Removed active assumed supervisor and budget-unit-head defaults; historical master remains unchanged. Added submitted-versus-approved status handling and private trip record separation. Preserved all eight airfare rules and exact five-item checklist. No new claim of live institutional policy verification; the 14-day airfare lead-time and normal 60-day claims notice are dated observations, not a blanket authorization deadline.
