# Mandatory Airfare Booking Evidence and Audit Compliance

**Priority:** Critical — applies to every airline booking.

**Authority:** UAH Business Services airfare booking and documentation instructions provided by the traveler.

## Objective

Ensure every official university airfare purchase is supported by contemporaneous evidence identifying the lowest-cost fare class available for the selected airline and itinerary.

The skill must proactively enforce this documentation workflow during airfare research, booking preparation, and reimbursement review.

## Rule 1 — Identify the lowest-cost fare

For every airline itinerary being considered:

1. Identify all fare classes offered for that specific itinerary.
2. Determine the lowest-cost available fare class.
3. Record the price and associated restrictions.
4. Check whether the selected fare is the lowest-cost available option.
5. Verify whether lower-priced fare classes are available, sold out, not offered, or not displayed.

Do not assume the lowest-cost product is available because it exists elsewhere on the airline's website.

Apply this requirement to Delta, American, United, Southwest, and all other airlines using their actual fare products.

## Rule 2 — Mandatory screenshots before booking

Before purchasing airfare, capture sufficient screenshots to establish the availability and pricing of the lowest-cost fare class.

The evidence should demonstrate, wherever the booking interface permits:

- Airline and booking source.
- Origin and destination.
- Departure and return dates.
- Flight selection or itinerary.
- Number of travelers.
- Cabin and fare-class settings.
- Whether lower-priced fare classes were included in the search.
- Lowest-cost fare-class availability.
- Selected fare class and price.
- Search date and time.

If the information cannot be captured in one screenshot, capture multiple screenshots.

Screenshots must reflect the same relevant search parameters as the selected itinerary.

Evidence must be retained before completing the purchase.

## Rule 3 — Higher fare-class selection

If the traveler selects a higher fare class:

**Case A: Lower fare sold out**

Capture screenshots showing that the lower fare was sold out or unavailable.

**Case B: Lower fare not displayed**

Capture the fare results and applicable search settings. Where the screenshots do not conclusively demonstrate unavailability, obtain additional evidence or flag the issue for Business Services.

**Case C: Lower fare available**

Capture the lower and higher fare prices. Explain the reason for selecting the higher class and identify whether advance approval is required.

Do not classify a voluntary higher-fare selection as policy-compliant merely because it offers greater convenience, flexibility, or benefits.

## Rule 4 — Evidence validation

Before indicating that an airfare purchase is documentation-ready, the skill must verify:

- Correct airline and itinerary.
- Same travel dates.
- Matching flight or sufficiently identified itinerary.
- Correct number of passengers.
- Fare-class comparison is visible.
- Lower fare availability status is documented.
- Selected fare and price are recorded.
- Screenshots were captured at booking time.
- Supporting documents are retained.

If any essential evidence is missing, flag the documentation as incomplete.

Do not automatically certify compliance based solely on screenshots that ambiguously omit lower fare classes.

## Rule 5 — Booking readiness control

Before an airfare purchase, the skill must provide a pre-booking evidence checklist.

Classify the result as:

- **Evidence complete:** Required comparisons are documented.
- **Evidence incomplete:** Additional screenshots or confirmation are needed.
- **Policy review required:** Lower fare was available, or selection requires a justification/approval.

Do not recommend proceeding as fully compliant while mandatory evidence is missing.

Obtain explicit user permission before making a purchase.

## Rule 6 — Reimbursement review

During post-trip reimbursement, compare the purchased fare class against the contemporaneous evidence.

If a higher fare was purchased without documentation demonstrating that the lowest-cost fare class was unavailable:

1. Flag the purchase for potential upgrade treatment.
2. Identify the documentation deficiency.
3. Explain that Business Services may use a retrospective cost comparison.
4. Calculate any potential reimbursement difference only when reliable comparison amounts are available.
5. Distinguish the traveler-paid amount from the potentially reimbursable amount.
6. Refer the final determination to Business Services.

Never fabricate a historical airfare price or present today's fare as the actual fare available at the original booking time.

## Rule 7 — Evidence package

Create an airfare evidence folder containing:

- Original flight search results.
- Lowest-fare availability screenshots.
- Selected fare-class screenshots.
- Booking confirmation.
- Actual payment receipt.
- Any required justification or approval.

Use descriptive filenames with the booking date, airline, route, and evidence type.

## Rule 8 — Proactive reminders

Whenever the user asks the skill to find, compare, or book flights, explicitly remind the traveler:

"Before purchasing, capture the lowest-fare availability and selected-fare screenshots. UAH Business Services requires evidence from the time of booking, particularly when a higher fare class is selected."

This rule must trigger automatically for all airlines and all official university airfare bookings.

## Final validation

Test the workflow with:

1. Delta Main Basic available.
2. Delta Main Basic explicitly sold out.
3. Delta Main Basic absent from the displayed results.
4. Another airline's lowest-cost fare product unavailable.
5. A higher fare class selected despite a lower fare being available.
6. A completed trip with missing contemporaneous screenshots.

Ensure every test correctly identifies required documentation, unresolved ambiguity, compliance risks, and possible reimbursement reductions. Add a Pre-Booking Audit Checklist to the skill. Every time it finds a flight, it should ask whether the screenshots have been captured before recommending the booking as documentation-ready.

Airfare documentation readiness

5/5

Lowest-cost fare class identified

Lowest fare availability screenshot captured

Selected fare and price screenshot captured

Dates, flights, passengers and settings match

Evidence retained with booking documentation

Evidence checklist complete — subject to policy review where needed.

This is particularly important for your situation because screenshot evidence showing that a lower fare is explicitly sold out is stronger than evidence where the lower fare is simply absent from the booking interface.

I would give this airfare evidence requirement the highest priority in the skill's booking workflow, so it is checked automatically rather than relying on you to remember it each time.

