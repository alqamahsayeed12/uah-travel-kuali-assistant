# Scripts and input setup

Python 3.9+ standard library only; no accounts, network calls, external packages, telemetry or credentials. Scripts read JSON and local evidence and print JSON. Run from the skill folder; keep trip inputs and outputs in a separate authorized private directory.

```
python3 scripts/airfare_audit.py /private/trip/manifest.json
python3 scripts/travel_calc.py /private/trip/calculation.json
python3 -m unittest discover -s tests -v
```

The /private/trip paths above illustrate a user-chosen private destination; these commands do not create it. Copy assets/airfare-manifest.json to a trip folder and populate it per airfare-audit.md; the bundled skeleton must fail readiness. Do not reuse synthetic test evidence as real evidence.

## travel_calc operations

All financial values are decimal strings in one declared currency after documented conversion. Money rounds half-up to cents for display. Unknowns must be null, not zero. See tests/test_travel.py for runnable synthetic inputs and assertions. `run()` dispatches:

- `route`: country (ISO US or foreign code), region (US subdivision), authorization_approved (ISO date or omitted). Outputs benchmark source, reimbursement branch and Kuali process. Country/territory and authorization date must be verified by the agent.
- `hotel`: checkin/checkout ISO dates (checkout exclusive), locality, source (GSA/DTMO/State), tolerance (default 50), rates and nights. Rate: locality, source, start/end inclusive, lodging, citation. Night: date, base, tax, fees, transport. Exactly one rate per night; overlaps/missing source fail. Output nightly band, benchmark delta and hotel+transport total. Taxes/fees and transport must be separately sourced, not presumed included.
- `mileage`: locality, rates, legs. Rate: locality, source=UAH, start/end, per_mile, citation. Leg: date, miles. Dates select rates; eligibility is separate. Do not additionally add fuel to mileage for the same expense.
- `meals`: method=per_diem, method_verified=true, policy_conflict_unresolved=false, policy_citation, deduction_order (deduct_then_factor or factor_then_deduct), days. Day: date, meals (excluding incidentals), incidentals, provided_meals (amount list), factor (explicit verified fraction). No automatic federal/UAH method; fails while conflict unresolved. Supply official daily breakdown; do not add combined M&IE plus incidentals. Actual meal method uses supported expenses via reconcile.
- `scenarios`: scenarios list, each name, hours, optional documented ceiling, components with unique id, amount (null if unknown), payer. Economic cost counts each cost once irrespective of payer. Incomplete totals are never ranked as cheapest. `ceiling` is displayed as supplied, not an enforced policy calculation: the agent must apply verified lesser-cost rules and document approval separately.
- `reconcile`: currency, expenses. Each: id, category, date, merchant, amount, authorized_estimate, currency, payer (traveler/UAH/P-Card/sponsor), state (posted/hold/estimate/void), receipt (private source reference), proof_of_payment, original_reviewed, eligible_amount, policy_verified, policy_citation. Supported eligibility cannot exceed actual charge. Only posted records count as actual. Direct-paid amounts are included in economic cost but not reimbursed to traveler. Potential duplicate records remain unresolved; recorded gross totals are explicitly before duplicate resolution. Invoice, receipt and card statement for the same transaction should be one expense ID with several evidence references, not three expenses. Remaining unknowns keep final reimbursement total null.

These helpers do not inspect receipts/screenshots, determine allowable costs, apply reimbursement ceilings automatically, fetch live prices, create original evidence or submit anything. Build the evidence-backed inputs with the host's research/document tools. In a host without Python execution perform transparent calculations and mark scripts not run; never claim successful automated validation.

## Packet reconciliation
Use [packet input contract](packet-reconciliation.md) and `scripts/packet_reconcile.py` to detect inconsistent totals, duplicate costs, stale source dependencies and unverified saves/uploads. It is separate from the airfare readiness audit.
