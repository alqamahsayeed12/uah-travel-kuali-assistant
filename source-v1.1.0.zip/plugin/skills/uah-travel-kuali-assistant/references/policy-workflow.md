# Authority, verification and updates

Start from source-register.json. For each new trip open current UAH Travel Information, Training and applicable guidelines; follow linked current documents. Identify trip and expense scope, employee status, payment method and sponsor. Applicable law and binding funding restrictions, UA System policies, UAH rules and authorized ESSC instructions must be reconciled according to scope; departmental preferences cannot override restrictions. Do not substitute University of Alabama Tuscaloosa or another institution's Kuali instructions for UAH.

Index each conclusion with source ID/title, URL or authorized private location, section/page, publication/effective date, verification date, concise rule, trip applicability and status. Search the register and full authorized documents by terms such as airfare, lowest available, interrupted travel, lodging, meals, incidentals, mileage, P-Card, international, authorization and receipts. Do not bundle protected manuals or private correspondence in the reusable package.

## Verified public findings, 2026-10-28

UAH Travel Information and the September 28 announcement confirm consolidated Kuali effective October 1, 2026. Travel Information explicitly permits manual processing where authorization was approved before October 1. Select legacy handling by actual authorization approval date and the applicable exception, not merely trip date. Older email/manual submission guidance on the same page is not the default for new authorizations.

UAH's currently linked Travel Guidelines are marked revised November 21, 2023 (despite the filename). Transportation §4 calls for lowest available airfare; economy/coach is the ordinary reimbursable class. Transportation and lodging sections require original evidence and itemized hotel documentation. Out-of-State §4 describes employee overnight M&IE per diem, 75% first/last days and supplied-meal deductions. This conflicts with the Travel Information page's dated 2022 statement about actual meals excluding incidentals. Flag the conflict and verify current applicable treatment before finalizing meal reimbursement. Do not apply federal percentages automatically or pay incidentals twice.

UAH's linked P-Card guide, dated May 24, 2013, separates business/personal travel and payment channels, calls for drive/fly comparisons and a lesser-cost ceiling, and restricts personal charges. Its manual form language needs reconciliation with Kuali. Recheck payment-specific rules before advising a charge.

Travel Information lists date-effective mileage: January 1, 2026 72.5 cents; July 1, 2026 76.0 cents. The linked IRS benchmark and another UAH page may differ; verify applicable dates and authority rather than silently using a familiar IRS value. It also lists Alabama in-state allowances; resolve actual-expense eligibility and duration boundaries using current rules. Do not default Alabama travel to GSA.

## Gaps requiring verification

The two Kuali training folders redirect to Google sign-in. No authenticated field/routing verification was performed. The 14-day departmental target, Self Service navigation and named approvers are supplied defaults, not independently verified current rules. Read authorized materials or ask for current instructions before official preparation.

The complete eight-rule screenshot protocol is user-supplied Business Services guidance. The public lowest-airfare rule supports its purpose, but public sources reviewed do not independently establish every screenshot requirement. Enforce the user protocol and cite its provenance accurately.

## Update process

Refresh only relevant sources with authorized tools. Add a new dated register entry and policy-version-log record with previous/new text summary, effective period, affected workflow, conflict disposition and verification result. Preserve old entries for historical claims. If a source is inaccessible, retain last-known metadata and mark current applicability unverified. Re-run tests after changing calculations, audit logic or rule interpretation; review the six scenario rubrics. Do not store volatile flight/hotel prices as durable policy.
