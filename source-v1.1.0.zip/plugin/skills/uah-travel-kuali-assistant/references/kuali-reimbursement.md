# Authorization, navigation, reimbursement and review

## AUTHORIZATION / KUALI_GUIDE

Confirm purpose, event times, dates, budget, sponsor restrictions, current lead time, approval route and plan comparisons before drafting. The form snapshot reviewed October 29 states airfare should be obtained at least 14 days before departure; this does not establish an authorization filing deadline. Its normal claims window is 60 days from when expenses were incurred. Recheck current applicable instructions and exceptions. UAH's official Training page links Kuali Travel Process and Test Practice Materials; both require authenticated access in this environment. Do not create fictitious field names. Use the current approved university interface and authorized training: ask the traveler to sign in through the university themselves if needed, then inspect only authorized content. Verify Self Service/Kuali Build navigation on screen. Keep practice environment separate from production.

Use assets/kuali-checklist.md and field-map.csv to map draft concepts to observed current fields, attachments and sources. Prepare business justification, conference/venue, travel window, itemized airfare/hotel/ground/meals/registration/total, funding if supplied, comparisons, agenda, evidence and exceptions. Mark missing routing or funding. Review entire completed form and attachments with traveler before asking action-specific approval to submit/certify/finalize. Retain observed confirmation/ID/time after any authorized submission; an attempted click is not proof of success. No credentials in documents.

## STATUS

Read approval/return/payment state only from authorized live interface or user-supplied dated notices. Quote returned issues accurately, identify required corrections and who needs to act based on verified routing. Distinguish draft, submitted, routed, approved, paid and returned; unknown stays unknown. Never infer approval from elapsed time or a draft form. Do not edit or resubmit official records without explicit approval.

## REIMBURSE

Read originals in an approved private workspace. Extract transaction date, merchant/category, currency, final posted amount, itemization, payer and proof of payment. Separate hotel folio, booking agency invoice, card hold and final charge; reconcile overlapping documents rather than summing each as a separate expense. A confirmation is not proof of payment. Identify duplicates by source identifiers and possible duplicates by normalized merchant/date/amount/currency; investigate before excluding. Separate traveler, UAH/P-Card and sponsor payments. Do not claim direct-paid amounts again.

Compare actual versus authorized category estimates, document personal portions and approvals, apply verified meal adjustments and reimbursement rules, and list missing/unsupported records. Use assets/reimbursement.csv and deterministic reconciliation. Output Expense | Authorized estimate | Actual expense | Potentially reimbursable | Evidence status, with totals and differences, partial amounts/unknowns and payer ledger. Never submit estimates as incurred expenses. Missing receipt affidavit is an official process to verify, not automatically equivalent to an original receipt. Check current deadlines and historical policy applicability rather than relying on old manual routing.

Audit purchased airfare against original booking-time fare/product/price evidence. Missing lower-availability proof for a higher fare means potential upgrade treatment, named documentation deficiency, possible Business Services retrospective comparison and final institutional decision. Keep traveler-paid amount distinct from potentially reimbursable amount. Calculate a potential reduction only with reliable sourced comparison amounts applicable to the historical decision. A current screenshot cannot prove historical price. The audit's trusted-comparison input is a reviewer assertion requiring a retained source and accepted basis, not an invented number.

## COMPLIANCE / JUSTIFICATION

For exceptions establish source policy, factual timeline, supported alternatives and dollar differences, business necessity, approval status and reimbursement risk. Support late booking, unavailable low fare, voluntary higher class, drive/fly, changes, above-benchmark lodging, extra nights, receipts and conference requirements. Draft neutral factual text using assets/justification.md. Never invent necessity or assert approval. Preserve original bold questions and quoted messages when the user requests an inline revision; revise only their answers. Use assets/business-services-message.md for drafts; verify recipient and show draft, and send only with explicit authorization. An addressed inquiry is not sent by creating the draft.

Read [observed fields](kuali-observed-fields.md) and [document workflow](document-kuali-workflow.md) before form work. Historical named contacts in the preserved master are not current defaults.
