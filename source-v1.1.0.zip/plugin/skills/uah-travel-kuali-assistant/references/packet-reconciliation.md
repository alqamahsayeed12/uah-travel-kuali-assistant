# Packet reconciliation

Run `python3 scripts/packet_reconcile.py /absolute/trip/path/packet.json` after visual review and upload/save verification. It uses only the standard library. Unknown costs fail closed; do not replace them with zero. The script verifies declared values and file dependencies, not PDF pixels, browser state, policy, institutional approval or airfare audit. Run the separate airfare audit for flight readiness.

Input JSON fields:
- `budget`: list of `{category, quote, buffer, allowance, cost_ids}`. Amounts are decimal strings, nonnegative. Quote plus explicit buffer must equal allowance. Each economic cost ID occurs once. A credit should be netted and explained in source records rather than entered as a negative expense. Do not count a checked bag under both airfare and miscellaneous.
- `total`, `kuali_total`, `notes_total`, `combined_total`: independently inspected totals, not values copied blindly from the same calculation.
- `funding_allocations`: optional list of requested amounts. Omit or use null while unknown; this does not make funding ready or authorize filling it.
- `artifacts`: list of `{path, sha256, role, uploaded_sha256, dependencies}`. Paths relative to the input JSON or absolute. For role `upload`, provide the hash of the known file whose actual attachment and persistence were verified; leave missing when not verified. `dependencies` maps source paths to hashes used when building the artifact. Include the combined PDF with all component dependencies so a changed component invalidates it. A hash check cannot infer remote bytes from a filename alone; retain upload records and inspect actual attachment identity.
- `save_verified`: true only after checking values/notes/attachment versions in the reopened form. False for local-only preparation.

Keep this manifest in the private trip folder. Do not bundle a real trip input with the reusable skill. Use the first-person submission packet separately from preparation notes and readiness checks.
