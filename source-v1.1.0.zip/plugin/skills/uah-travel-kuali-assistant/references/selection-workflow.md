# Traveler selection before detailed evidence capture

Latest user workflow, October 28, 2026. This overrides older instructions requiring the complete screenshot package during initial candidate research. It changes timing only; mandatory pre-purchase evidence and the exact five-item airfare audit remain required.

## Stage 1 — first draft for selection

Show researched flight options with booking/search links, exact dates/times, flights, connections, fare family, price, restrictions and source/time; or a sourced driving-cost comparison when relevant. Apply personal routing preferences. Show hotel options with direct property or exact-date booking links, room types, dates/occupancy, total price and cancellation terms where verified. Unknown inventory, terms and amounts stay unverified/TBD. Include expected ground transport and registration in the budget. Ask the traveler to choose an itinerary/drive option and a specific hotel AND room type. Do not make a selection for them. Do not block the first draft on the detailed screenshot package. Mark airfare Evidence incomplete — awaiting selection and evidence capture; retain the exact five-item readiness checklist, with only supported checks. Links and quoted prices are preliminary research, not substitutes for later required screenshots. Any screenshots already incidentally retained remain research evidence.

## Stage 2 — selection approval and evidence

Record the user's explicit itinerary or driving selection and hotel plus room-type selection in the private trip record, separate from UAH/institutional approval. Approval to select authorizes read-only detailed research and screenshot capture, not purchase, reservation, payment, submission or certification. Continue independently for components already selected while waiting on other selections.

For approved flights, re-open the exact dates/flights/travelers/settings, reprice and capture the complete mandatory airfare evidence: lowest available product and lower-class states, selected fare/price, restrictions, source/time/currency, and matching settings for every segment. Recheck immediately before any future purchase. If price, schedule, fare family, hotel room, cancellation terms or total changes materially from the selected option, show the change and obtain revised selection approval; never silently substitute. Preserve sold-out versus absent/not-displayed distinctions and explicit traveler screenshot confirmation. Capture capability failure means Evidence incomplete, not compliant.

For approved driving, retain route-map distance/time screenshots, date-effective applicable mileage policy/rate, detailed driving/flying comparison and documented approval status. Do not invent university approval or double count fuel and mileage.

For the approved hotel and room type, capture exact check-in/out, occupancy, room category, nightly price, total taxes and mandatory fees, payment/cancellation terms with deadlines/timezone, source and observation time. A generic hotel homepage does not establish room inventory. User selection is not a reservation or payment. Retain existing reservation evidence if already booked; a current quote does not prove historical terms.

## Uber expected-cost screenshots

For each relevant route, seek an actual Uber estimate and capture a screenshot showing pickup/dropoff context, direction, ride product, expected fare/range, currency, observation date/time and any requested/scheduled ride time. Include home–origin airport and return, destination airport–hotel and return, and hotel–conference and return on attendance days. Do not infer that reverse fares are identical; record repeated-route assumptions explicitly. Never substitute a web snippet, another provider's price, or an invented image for an Uber screenshot. Estimates are not guaranteed fares, receipts, reservations or proof of reimbursement eligibility; identify surge, schedule, fees/tolls and tip uncertainty where applicable. If future-date estimates are unavailable, label the actual estimate date/time and its planning limitation. Do not book/request a ride. If access requires login or a precise home address, request only necessary information and obtain authorization before transmitting sensitive location data to Uber; do not store credentials. If unavailable, mark screenshot and cost pending and ask the user for the estimate screenshot rather than inventing a price. Keep protected route details in the trip folder, not in reusable skill files.

## Stage 3 — reviewable authorization package

Combine approved selections, evidence, budget, registration, meal adjustments, funding and attachment gaps. Present actual checklist status. Missing evidence prevents readiness; missing university approval stays pending. Ask separately for any future purchase/submission action. No booking or submission is authorized by this workflow update.
