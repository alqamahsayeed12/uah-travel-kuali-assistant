# Master and airfare requirements coverage

The full original master is preserved in master-prompt.md; the latest protocol is in airfare-eight-rules.md. Supporting instructions are operational, not merely an outline. Host-dependent research is performed by the invoking agent with available tools; no standalone Python program claims to replace browsing or institutional authority.

| Master sections | Implementation | Verification |
|---|---|---|
| 1, 19, 23 identity, actual private reusable files/package | SKILL.md, agents/openai.yaml, INSTALL.md, standalone and portable plugin ZIPs | Package/link/hash/YAML/archive checks; installation deliberately pending approval |
| 2 principles and evidence distinctions | SKILL.md, policy-workflow.md, all calculation outputs | Unknowns remain unknown; no compliance/purchase certification |
| 3 all editable defaults | assets/settings.json | Defaults reviewed against source master; departmental items marked unverified |
| 4 authority, sources, transition/conflicts | source-register.json, policy-workflow.md, policy-version-log.md | Public UAH/government/carrier research; authentication gaps recorded |
| 5 twelve modes | SKILL.md routes, research-workflows.md, kuali-reimbursement.md | PLAN/FULL_TRIP plus all focused modes documented |
| 6 schedule intake | research-workflows.md, travel report A | Event/timezone feasibility checklist; actual event testing pending trip |
| 7 live flights and airports | research-workflows.md, flight-comparison.csv, airfare audit | Six airfare cases, query/settings/return-leg mismatches |
| 8 rates/date/locality/UAH distinction | research-workflows.md, date-effective calculators | Master 3–5, missing/overlapping rates, Alabama refusal |
| 9 hotel search, five options, per-night ±$50, amenities | research-workflows.md, hotel table, hotel calculator | Master 1/3/5 and lower-band clamp; live inventory pending |
| 10 driving/flying | research-workflows.md, mileage/scenario helpers | Master 2, effective mileage boundary |
| 11 full economic cost/three scenarios/payers | scenarios, cost analysis/report F | Master 1/2/6, partial totals never ranked cheapest |
| 12 Kuali preparation/navigation/action approval | kuali-reimbursement.md, field map, Kuali checklist | Transition/legacy date tests; authenticated navigation pending |
| 13 evidence package and genuine originals | airfare-audit.md, inventory, trip folder convention | Integrity, mismatch, capture time and incomplete-record tests |
| 14 post-trip reconciliation | reconcile helper, reimbursement table | Master 6, duplicates, direct-paid, holds, unsupported claims |
| 15 exceptions | kuali-reimbursement.md, justification/message templates | Higher-fare review and approval-document cases; factual drafting rubric |
| 16 exact executive + A–J output | travel-report.md | Structure reviewed against master |
| 17 quality controls | SKILL.md, research checklist, calculator errors | Numeric/date/evidence edge cases and acceptance walkthroughs |
| 18 privacy/actions | SKILL.md, INSTALL.md | No credentials/receipts/advice bundled; no installation or external action |
| 20 all six master tests | test_travel.py, acceptance-walkthroughs.md | Automated synthetic calculations plus author-reviewed workflow exercises |
| 21 maintenance/versioning | policy workflow, source register/version log | Append-only process; no silent historical overwrite |
| 22 example commands A–F | INSTALL.md examples and mode instructions | Retrospective contradiction in Example E explicitly resolved |

| Latest airfare rule | Implementation and test |
|---|---|
| 1 lowest available per exact flight | Fare observations, full segment query, computed minimum; cases 1/2/4 |
| 2 screenshots before purchase | Required original files, captured_at, exact query, confirmation and retention; missing/stale/future tests |
| 3 sold out vs absent vs voluntary higher | Distinct statuses and independent review flag; cases 2/3/5 |
| 4 evidence validation | Query equality, prices, integrity, reviewed observations; mismatch/return-leg tests |
| 5 readiness gate and permission | Five actual checks; incomplete/review/complete; purchase_permission always false |
| 6 reimbursement historical comparison | Purchased-v-selected match, booking-time reference, unknown reduction unless reliable; case 6/current-v-historical tests |
| 7 evidence folder contents | Private trip airfare-evidence convention; confirmation/receipt required after purchase, pending before |
| 8 automatic reminder and exact 5/5 labels | SKILL.md mandatory trigger, pre-booking-checklist.md; not dependent on traveler remembering |

The deterministic checks validate supplied reviewed records, not pixels, provenance, policy authority or actual bookability. The acceptance walkthroughs disclose which portions were author review rather than installed-host testing. There is no institutional compliance certification.
