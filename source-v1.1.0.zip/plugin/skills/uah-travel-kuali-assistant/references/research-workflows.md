# Research workflow operations

## Intake and PLAN / FULL_TRIP

Read the relevant master sections in full. Collect origin, exact venue and address, event agenda with attendance times, travel dates/year and timezone, business purpose, funding/sponsor, necessary arrival buffer, optional flexibility/personal days, hotel needs and existing approvals/reservations/payments. Research supplied event URLs. Work with origin/destination/venue/dates while resolving necessary missing event-time or funding details; label assumptions and do not claim final policy readiness. Determine feasible business travel days, hotel check-in/out and eligible nights separately from preference. Ensure flights plus transfers, security, layovers and delay buffers permit attendance, including time-zone and date-line changes.

## FLIGHTS

Apply personal-preferences.md before ranking: connection floor 45 minutes, prefer nonstop/one stop, after-10-a.m. departures, before-6-p.m. arrivals including HSV, no overnight travel, Delta preferred with alternatives. Explain tradeoffs and mark failed or unverified constraints.

Research three feasible exact-date bookable itineraries when available. Use airline/authorized booking inventory; snippets and generic fares are leads only. Return flight numbers, operating/marketing carrier, airports, local departure/arrival dates/times/timezones, duration, stops and layovers, fare family, total mandatory-price basis/currency, bags, change/cancellation terms, source URL and observed timestamp. Distinguish seats from fare inventory. Apply the airfare gate to each candidate and every leg, outbound and return. If only a bundle is priced, do not invent per-leg amounts; prove all included segments are covered.

Default HSV. Evaluate BNA/BHM/ATL when useful, with route miles and driving time, mileage OR fuel (avoid both for the same mileage reimbursement), parking, ground transfers, extra overnight costs, reimbursement constraints and travel burden. Compare least full cost, best value and reasonable convenience. Higher prices require a factual rationale and policy review, not an implied entitlement.

Carrier source checks: Delta's published Main Basic (formerly Basic Economy) and higher products; American Basic Economy and Main Cabin, including filters that may suppress Basic; United Basic Economy and current economy products; Southwest Basic, Choice, Choice Preferred and Choice Extra. Re-open current carrier sources in the register and actual fare rules for the specific market/date. Do not rely on historical Southwest names or free-bag assumptions. Product pages never prove availability for a flight. If a page needs JavaScript or sign-in, use an authorized browser or mark restrictions unverified. Resolve conflicting carrier pages against exact ticket rules; do not infer restrictions from a name alone.

## PER_DIEM

Select GSA for CONUS, DTMO for Alaska/Hawaii and applicable non-foreign U.S. areas, State for foreign destinations. This geographical source selection is a benchmark; Alabama has a separate UAH/state reimbursement branch. Resolve locality/county/designated boundaries, rate year/effective dates, seasonal nights and monthly/fiscal-year transitions from official tables. Retrieve lodging, meals and incidentals separately where supported, supplied-meal breakdown and applicable partial-day rules. If M&IE already includes incidentals, never add incidentals again. Do not split combined figures without an official breakdown.

Output date | locality | lodging benchmark | meals | incidentals | source/effective date. Actual trip dates govern, not research date. Do not apply federal employee entitlements, actual-expense exceptions or 75% factors unless current UAH applicability is established. The policy conflict in policy-workflow.md must be resolved before final meal calculations. DTMO fetch returned 403 at creation: retry through available official/browser channels or request an authorized rate extract; no guessed rates.

## HOTELS (required for overnight trips)

Research five suitable available hotels when possible, for exact check-in/out and occupancy. Per-night discovery band is max(0, official lodging benchmark − editable tolerance) through benchmark + tolerance, default $50. Compute each night independently across rate changes. Price preference is not a reimbursement cap or permission to exceed one.

For each option provide hotel/address, bookable room category/occupancy, nightly pre-tax price and benchmark delta, nights, itemized taxes and mandatory fees, total, cancellation deadline with timezone/refund terms, verified venue distance and walking/transit/driving time, daily local transport and parking, breakfast and amenities, availability, source URL and observed timestamp. Separate estimates from verified taxes. A kitchenette requires evidence of a usable stove/cooktop; microwave/fridge alone is not a full kitchenette. Do not assert neighborhood safety without support. Compare conference rates. Group within/below benchmark, within tolerance above, or outside preferred range with reasons; identify below-band bargains explicitly. Show outside-range options when scarcity or total value justifies it.

## COMPARE and total optimization

For verified drives of seven hours or less one-way, perform the personal-preferences driving-policy review. Include all three round-trip taxi categories in flying/hotel costs, counting attendance days explicitly. Unknown taxi fares remain TBD.

Compare door-to-door economic cost and time, not headline prices. Drive: eligible mapped mileage at applicable date-effective UAH rate, parking, tolls, extra nights, meals and travel time. Fly: fare, bags, origin transfers/parking, destination transport/rental, schedule-induced lodging and time. Verify any lesser-of-drive/fly ceiling, comparison lead time and exceptions; do not reconstruct an old quote as contemporaneous. Example E in the master cannot be satisfied retroactively without original contemporaneous evidence: produce a labeled retrospective analysis and request Business Services review.

Create A lowest feasible full cost, B best value, C convenience, showing dollar differences and supported tradeoffs. Include transportation, lodging, taxes/fees, eligible meals/incidentals, registration and other allowable expenses once. Separate total economic cost, UAH-paid/payable, traveler outlay, potentially reimbursable, approvals and personal/nonreimbursable portions. Unknown components make the total partial. Use source-backed inputs and deterministic helpers. Retain airfare/room inventory, government rates, agenda, route maps, calculations and policies in the private trip inventory.

## Report and final checks

Fill assets/travel-report.md and CSV tables. Check event attendance/timezones, exact stay/flight dates, county/season/year, arithmetic, taxes versus room price, meal/transport duplication, personal days, preapproval, source dates and Kuali evidence. Use the master compliance labels with a source for each finding. Do not call a recommendation an authorization. For inaccessible live tools produce a supported draft and precise gaps; do not claim live availability or a connected Kuali account.

## Selection gate before detailed capture
Follow selection-workflow.md: first draft options and hotel/room links, user selection, detailed matching screenshots, then final review. Initial airfare status remains Evidence incomplete. Uber prices need actual estimate screenshots or a clearly marked pending gap.
