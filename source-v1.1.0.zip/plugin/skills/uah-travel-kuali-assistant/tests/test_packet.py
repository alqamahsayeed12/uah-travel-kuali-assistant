import unittest,tempfile,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from packet_reconcile import reconcile
class Packet(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);(self.root/'component.pdf').write_bytes(b'synthetic source');(self.root/'combined.pdf').write_bytes(b'synthetic bundle')
  h=lambda f:hashlib.sha256((self.root/f).read_bytes()).hexdigest()
  self.d={'budget':[{'category':'airfare','quote':'700.00','buffer':'100.00','allowance':'800.00','cost_ids':['ticket']},{'category':'misc','quote':'100.00','buffer':'25.00','allowance':'125.00','cost_ids':['bag']}], 'total':'925.00','kuali_total':'925.00','notes_total':'925.00','combined_total':'925.00','funding_allocations':['925.00'],'save_verified':True,'artifacts':[{'path':'combined.pdf','sha256':h('combined.pdf'),'role':'upload','uploaded_sha256':h('combined.pdf'),'dependencies':{'component.pdf':h('component.pdf')}}]}
 def tearDown(self):self.tmp.cleanup()
 def check(self):return reconcile(self.d,self.root)['consistent']
 def test_valid(self):self.assertTrue(self.check())
 def test_old_notes(self):self.d['notes_total']='900';self.assertFalse(self.check())
 def test_old_combined(self):(self.root/'component.pdf').write_bytes(b'updated');self.assertFalse(self.check())
 def test_upload_unknown(self):self.d['artifacts'][0].pop('uploaded_sha256');self.assertFalse(self.check())
 def test_extra_buffer(self):self.d['budget'][1]['buffer']='50';self.assertFalse(self.check())
 def test_duplicate_baggage(self):self.d['budget'][0]['cost_ids'].append('bag');self.assertFalse(self.check())
 def test_unsaved(self):self.d['save_verified']=False;self.assertFalse(self.check())
 def test_funding(self):self.d['funding_allocations']=['900'];self.assertFalse(self.check())
 def test_unknown_cost(self):self.d['budget'][0]['quote']=None;self.assertFalse(self.check())
 def test_nonfinite(self):self.d['budget'][0]['quote']='NaN';self.assertFalse(self.check())
if __name__=='__main__':unittest.main()
