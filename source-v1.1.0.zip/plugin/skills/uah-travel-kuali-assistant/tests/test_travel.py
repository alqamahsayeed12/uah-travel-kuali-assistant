"""Six required master scenarios using synthetic rates/quotes, plus financial edge cases."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from travel_calc import run,hotel,mileage,scenarios,reconcile,meals,source_for,kuali_process

def rate(start,end,amount,source='GSA',locality='TEST'):
    return {'start':start,'end':end,'lodging':amount,'source':source,'locality':locality,'citation':'SYNTHETIC TEST RATE, not government evidence'}

def expense(id,amount,payer='traveler',receipt=True,state='posted',merchant=None):
    return {'id':id,'date':'2026-11-14','category':id,'merchant':merchant or id,'amount':amount,'authorized_estimate':amount,'currency':'USD','payer':payer,'state':state,'receipt':'SYNTHETIC record' if receipt else None,'proof_of_payment':receipt,'original_reviewed':receipt,'eligible_amount':amount,'policy_verified':True,'policy_citation':'SYNTHETIC explicit policy assumption'}

class TravelTests(unittest.TestCase):
    def test_master_01_four_night_dc_conference(self):
        data={'checkin':'2026-11-10','checkout':'2026-11-14','locality':'TEST','source':'GSA','rates':[rate('2026-11-01','2026-11-30','200')],'nights':[{'date':f'2026-11-{d}','base':'230','tax':'23','fees':'10','transport':'0'} for d in range(10,14)]}
        r=hotel(data);self.assertEqual(r['hotel_and_transport_total'],'1052.00');self.assertEqual(len(r['nights']),4);self.assertEqual(r['nights'][0]['lower'],'150.00');self.assertEqual(r['nights'][0]['upper'],'250.00');self.assertFalse(r['reimbursement_authorized'])
        ss={'scenarios':[{'name':name,'hours':hours,'components':[{'id':'flight','amount':fare,'payer':'traveler'},{'id':'hotel','amount':'1052','payer':'traveler'},{'id':'registration','amount':'300','payer':'P-Card'}]} for name,fare,hours in [('A','280',8),('B','330',5),('C','450',3)]]}
        x=scenarios(ss);self.assertEqual([s['known_economic_cost'] for s in x['scenarios']],['1632.00','1682.00','1802.00']);self.assertEqual(x['scenarios'][1]['difference_from_lowest_complete'],'50.00');self.assertEqual(x['scenarios'][0]['UAH_direct_paid'],'300.00')
    def test_master_02_driving_vs_flying(self):
        m=mileage({'locality':'TEST','rates':[dict(rate('2026-01-01','2026-12-31','0',source='UAH'),per_mile='0.70')],'legs':[{'date':'2026-11-10','miles':'600'}]})
        self.assertEqual(m['total'],'420.00')
        def components(items):return [{'id':i,'amount':v,'payer':'traveler'} for i,v in items]
        x=scenarios({'scenarios':[{'name':'drive','hours':12,'ceiling':'600.00','components':components([('mileage','420'),('parking','40'),('tolls','20'),('extra_hotel','120')])},{'name':'fly','hours':7,'components':components([('airfare','350'),('bags','35'),('origin_transport','50'),('destination_transit','45'),('schedule_lodging','120')])}]})
        self.assertEqual([s['known_economic_cost'] for s in x['scenarios']],['600.00','600.00']);self.assertEqual(x['scenarios'][0]['hours'],12)
    def test_master_03_seasonal_month_and_fiscal_year_boundary(self):
        x=hotel({'checkin':'2026-09-30','checkout':'2026-10-02','locality':'TEST','source':'GSA','rates':[rate('2026-09-01','2026-09-30','180'),rate('2026-10-01','2026-10-31','220')],'nights':[{'date':'2026-09-30','base':'200','tax':'20','fees':'0','transport':'10'},{'date':'2026-10-01','base':'240','tax':'24','fees':'0','transport':'10'}]})
        self.assertEqual([n['upper'] for n in x['nights']],['230.00','270.00']);self.assertEqual(x['hotel_and_transport_total'],'504.00')
    def test_master_04_alabama_not_automatic_federal_method(self):
        x=run({'operation':'route','country':'US','region':'AL'})
        self.assertIn('Alabama',x['reimbursement_branch']);self.assertEqual(x['benchmark_source'],'GSA')
        with self.assertRaises(ValueError):meals({'method_verified':False})
    def test_master_05_international_sponsor_restrictions(self):
        x=run({'operation':'route','country':'FR','region':'Paris'})
        self.assertEqual(x['benchmark_source'],'State');self.assertEqual(source_for('US','HI'),'DTMO');self.assertEqual(source_for('US','AK'),'DTMO')
        # The deterministic tool deliberately makes no Fly America/award exemption decision.
        self.assertNotIn('carrier_approved',x)
        x=hotel({'checkin':'2026-11-10','checkout':'2026-11-11','locality':'TEST','source':'State','rates':[rate('2026-11-01','2026-11-30','250',source='State')],'nights':[{'date':'2026-11-10','base':'260','tax':'26','fees':'5','transport':'9'}]})
        self.assertEqual(x['hotel_and_transport_total'],'300.00');self.assertFalse(x['reimbursement_authorized'])
    def test_master_06_post_trip_mixed_payers_and_missing_evidence(self):
        items=[expense('hotel','800'),expense('airline','350','P-Card'),expense('mileage','76'),expense('registration','200','sponsor'),expense('taxi','30',receipt=False),expense('card_hold','800',state='hold'),expense('duplicate','800',merchant='hotel')]
        x=reconcile({'currency':'USD','expenses':items})
        self.assertEqual(x['recorded_actual_total_before_duplicate_resolution'],'2256.00');self.assertEqual(x['traveler_outlay_before_duplicate_resolution'],'1706.00');self.assertEqual(x['known_potential_reimbursement'],'876.00');self.assertIsNone(x['reimbursement_total']);self.assertEqual(x['possible_duplicates'],[['hotel','duplicate']])
    def test_date_effective_mileage_not_hardcoded(self):
        rates=[dict(rate('2026-01-01','2026-06-30','0',source='UAH'),per_mile='.725'),dict(rate('2026-07-01','2026-12-31','0',source='UAH'),per_mile='.760')]
        x=mileage({'locality':'TEST','rates':rates,'legs':[{'date':'2026-06-30','miles':'100'},{'date':'2026-07-01','miles':'100'}]})
        self.assertEqual(x['total'],'148.50')
    def test_unknown_cost_never_cheapest(self):
        x=scenarios({'scenarios':[{'name':'unknown','components':[{'id':'fare','amount':None,'payer':'traveler'}]},{'name':'known','components':[{'id':'fare','amount':'300','payer':'traveler'}]}]})
        self.assertFalse(x['ranking_complete']);self.assertIsNone(x['scenarios'][0]['difference_from_lowest_complete'])
    def test_duplicate_id_and_mixed_currency_rejected(self):
        a=expense('a','100')
        with self.assertRaises(ValueError):reconcile({'currency':'USD','expenses':[a,a]})
        a['currency']='EUR'
        with self.assertRaises(ValueError):reconcile({'currency':'USD','expenses':[a]})
    def test_missing_or_overlapping_effective_rate_rejected(self):
        data={'locality':'TEST','rates':[],'legs':[{'date':'2026-11-01','miles':'10'}]}
        with self.assertRaises(ValueError):mileage(data)
        r=dict(rate('2026-01-01','2026-12-31','0',source='UAH'),per_mile='.7');data['rates']=[r,r]
        with self.assertRaises(ValueError):mileage(data)
    def test_explicit_meal_method_and_supplied_meal_adjustment(self):
        d={'method':'per_diem','method_verified':True,'policy_conflict_unresolved':False,'policy_citation':'SYNTHETIC approved method','deduction_order':'factor_then_deduct','days':[{'date':'2026-11-10','meals':'75','incidentals':'5','provided_meals':['15'],'factor':'.75'}]}
        self.assertEqual(meals(d)['total'],'45.00');d['policy_conflict_unresolved']=True
        with self.assertRaises(ValueError):meals(d)
    def test_legacy_exception_based_on_approval_not_trip_date(self):
        self.assertIn('Legacy',kuali_process('2026-09-30'));self.assertIn('Current',kuali_process('2026-10-01'));self.assertIn('Current',kuali_process())
    def test_lower_discovery_band_clamps_zero(self):
        x=hotel({'checkin':'2026-11-10','checkout':'2026-11-11','locality':'TEST','source':'GSA','rates':[rate('2026-11-01','2026-11-30','30')],'nights':[{'date':'2026-11-10','base':'20','tax':'2','fees':'0','transport':'0'}]})
        self.assertEqual(x['nights'][0]['lower'],'0.00')
    def test_unknown_payer_not_silently_direct_paid(self):
        e=expense('a','10',payer='unknown')
        with self.assertRaises(ValueError):reconcile({'currency':'USD','expenses':[e]})
    def test_duplicate_meal_days_rejected(self):
        d={'method':'per_diem','method_verified':True,'policy_conflict_unresolved':False,'policy_citation':'SYNTHETIC','deduction_order':'factor_then_deduct','days':[{'date':'2026-11-10','meals':'75','incidentals':'5','provided_meals':[],'factor':'1'}]*2}
        with self.assertRaises(ValueError):meals(d)
    def test_claim_above_paid_rejected(self):
        e=expense('a','10');e['eligible_amount']='11'
        with self.assertRaises(ValueError):reconcile({'currency':'USD','expenses':[e]})
if __name__=='__main__':unittest.main()
