import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from preference_check import check
class Preferences(unittest.TestCase):
 def route(self,**kw):
  r=dict(connection_minutes=[45],overnight=False,arrival_local_time='17:59',departure_local_time='10:01');r.update(kw);return check(r)
 def test_30_rejected(self):self.assertFalse(self.route(connection_minutes=[30])['eligible_for_recommendation'])
 def test_44_rejected(self):self.assertFalse(self.route(connection_minutes=[44])['eligible_for_recommendation'])
 def test_45_allowed(self):self.assertTrue(self.route()['eligible_for_recommendation'])
 def test_nonstop(self):self.assertTrue(self.route(connection_minutes=[])['eligible_for_recommendation'])
 def test_overnight(self):self.assertFalse(self.route(overnight=True)['eligible_for_recommendation'])
 def test_unknown(self):self.assertFalse(self.route(connection_minutes=None)['eligible_for_recommendation'])
 def test_1800_miss(self):self.assertIn('Arrival not before 6 p.m.',self.route(arrival_local_time='18:00')['preference_misses'])
 def test_two_connections(self):self.assertIn('More than one connection',self.route(connection_minutes=[60,60])['preference_misses'])
 def test_1000_miss(self):self.assertIn('Departure not after 10 a.m.',self.route(departure_local_time='10:00')['preference_misses'])
if __name__=='__main__':unittest.main()
