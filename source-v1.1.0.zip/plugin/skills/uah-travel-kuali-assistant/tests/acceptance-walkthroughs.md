# Acceptance walkthroughs and host test prompts

These are synthetic author-reviewed workflow exercises, not records of real travel or an installed Work session. Arithmetic and fail-closed audit behavior run in the automated tests. Source fidelity, practical recommendations, Kuali completeness and uncertainty handling were reviewed against the bundled instructions below; live/host-dependent behavior remains to be tested after installation.

## Master 1: four-night DC conference

Input: HSV, DC venue supplied, meeting November 11 at 9 a.m. through November 13 at 5 p.m., hotel November 10–14, 2026. Synthetic benchmark $200 and hotel $230 + $23 tax + $10 fee per night; three synthetic fares $280/$330/$450 and $300 P-Card registration.

Observed calculation: nightly discovery band $150–$250, four-night hotel $1,052, total scenarios $1,632/$1,682/$1,802, B is $50 above A. Direct-paid registration stays in economic total and outside traveler reimbursement. The hotel is within discovery tolerance, not automatically allowable. Readiness stays incomplete without actual fare screenshots. Choose the lowest feasible schedule after validating arrival/transfer buffer; do not choose solely by the synthetic dollar total. The implementation requires three actual flight searches and five exact-stay hotel searches, agenda, official date/locality rates, airfare audit and Kuali attachments. No real five-hotel inventory or DC rate was established by this fixture.

## Master 2: driving versus flying

Input: synthetic 600 mapped business miles at a supplied test-only $0.70 rate, $40 parking, $20 tolls and $120 extra lodging versus $350 airfare + $35 bag + $50 origin transfer + $45 destination transit + $120 schedule lodging. Drive 12 hours, fly 7 hours.

Observed calculation: $600 each; equal money does not imply equal practical value. Preserve route map, exact-flight fare comparison and dates, time burden, applicable lead-time rules and any verified lesser-cost ceiling. A current quote for a completed drive cannot become a contemporaneous comparison. The Kuali draft must identify comparison provenance and unresolved approval. This fixture's rate is intentionally not asserted as current UAH mileage.

## Master 3: seasonal lodging and fiscal-year boundary

Input: September 30–October 2 synthetic stay, benchmark $180 on September 30 and $220 on October 1. Room/tax/transport $200/$20/$10 then $240/$24/$10.

Observed calculation: nightly upper bands $230 and $270, hotel plus transport $504. Do not use an average benchmark for every night or use the wrong fiscal-year table. Retain both dated official rate extracts before treating the budget as supported. Missing/overlapping effective rates fail the calculator. Mark Kuali allowance unresolved until UAH applicability is verified.

## Master 4: Alabama trip

Input: Huntsville to an Alabama venue, duration and overnight count supplied by traveler.

Observed route output: GSA may be a geographical benchmark, but reimbursement follows the distinct Alabama branch and verified actual/per-diem eligibility. The meal calculator refuses an unverified method. The public UAH page and linked guidelines must be reconciled for duration boundaries and exceptions. Do not calculate federal 75% meals or a federal lodging entitlement by default. Kuali draft requires actual trip duration, approval, travel classification, mileage evidence and the applicable state/UAH rule.

## Master 5: international conference

Input: Paris venue, exact dates and a hypothetical federal sponsor award with carrier restrictions.

Observed route output: State Department benchmark; synthetic lodging + tax + fees + transit is $300 for the test night. No carrier approval decision is produced. Check official effective country/locality rates, UAH/system international registration, research security and actual award/Fly America requirements and documented exceptions; do not assume a foreign codeshare or Open Skies agreement qualifies. State rates are not automatically UAH reimbursement authority. Capture exact-ticket fare evidence across all segments and retain sponsor/approval material privately. DTMO routing is separately tested for Alaska/Hawaii. No international travel clearance was obtained.

## Master 6: completed trip and mixed payers

Input: synthetic hotel $800, P-Card airline $350, traveler mileage $76, sponsor registration $200, unsupported taxi $30, an $800 card hold, and a suspected duplicate $800 hotel transaction.

Observed result: recorded gross posted expense before duplicate resolution $2,256, traveler recorded outlay $1,706, known potential reimbursement $876, final reimbursement total unknown. Hold excluded; possible hotel duplicate flagged for review; missing taxi proof remains unresolved; direct-paid airline/registration are not reimbursed again. Cross-reference folio, agency receipt and card payment as evidence for one transaction. Missing contemporaneous airfare screenshots trigger a separate airfare deficiency/possible upgrade review, not a fabricated price. Kuali draft includes evidence inventory, actual-v-estimate reconciliation and missing-item list; no unsupported amount is certified.

## Airfare 1–6

| Case | Actual automated result | Required response |
|---|---|---|
| Delta Main Basic available and selected | Evidence complete, 5/5 on reviewed synthetic record | Lowest available recorded, restrictions retained, still no purchase permission |
| Delta Main Basic explicitly sold out | Evidence complete, 5/5 on matching synthetic proof | Higher available fare identified as lowest available; no general assumption |
| Delta Main Basic absent | Evidence incomplete plus policy review | Capture settings/additional proof; never relabel absence as sold out |
| Other lowest product unavailable | Evidence complete on explicit synthetic proof, tested American/United/Southwest | Match each carrier's actual products and exact itinerary; general product page insufficient |
| Higher fare selected while lower available | Policy review required, evidence itself complete 5/5 | Both prices/restrictions, factual rationale, verify advance approval; convenience does not certify |
| Completed trip missing original screenshots | Evidence incomplete plus policy review and potential upgrade treatment | Name deficiency, distinguish paid vs potential reimbursement, explain possible retrospective comparison; reduction unknown without reliable amount |

All complete synthetic records include the exact query, original-file integrity record, reviewed observations, timestamps and confirmation. They are test harness assertions, not actual screenshots of airline fare inventory. Altered/missing files, wrong return flight/passengers/settings/prices, stale/future captures and missing confirmation fail readiness. Current screenshots cannot establish historical fares. A reliable accepted historical comparison permits only a labeled potential difference, not an official reimbursement result.

## Work post-install acceptance

Use each input above with the registered skill and permitted synthetic sources, then a real user-authorized public trip research request. Confirm auto-selection, exact reminder and five checklist labels, visible screenshot question, honest live-access limitations, three flights/five hotels when available, correct official rate locality/dates, practical event feasibility, sourced policy findings, complete Kuali draft and no unauthorized actions. Inspect actual screenshot pixels; never reuse generated test fixtures as evidence. Test private visibility and installed resource access independently. These checks are pending because the skill has not been installed.

## October 29 workflow regression scenarios
- A displayed outbound Basic/Standard price gap with no selected return must remain a search-stage comparison; require final matching round-trip evidence before naming a final fare difference.
- A return search omits Basic after Standard outbound selection: absent, not sold out.
- Native PDF lacks source/date footer: retain original and flag missing proof privately; never add a fake browser footer.
- Traveler chooses a larger miscellaneous buffer: update itemization, category, total, funding allocations if known, narrative, combined PDF and uploaded version; preserve source quotes.
- User-edited description conflicts with amount: ask which is intended and do independent work while waiting.
- Supplied submitted form: inspect checkbox states visually, distinguish intended PCard category from payment, preserve private routing, report In Progress without claiming approval or agent submission.
- Save input reverts after reload: use supported input events and verify persistence; a successful click is insufficient.
- Request to open uploaded PDFs from originals: open the current local versions and distinguish queued UI requests from verified open tabs.
