"""Synthetic fixtures only: these assertions do not establish real screenshot provenance."""
import base64
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from airfare_audit import audit

PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jM3sAAAAASUVORK5CYII=')

class AirfareTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.file=self.base/'2026-10-28_Delta_HSV-DCA_synthetic-test-only.png';self.file.write_bytes(PNG)
        self.digest=hashlib.sha256(PNG).hexdigest()
        template=json.loads((Path(__file__).resolve().parents[1]/'assets/airfare-manifest.json').read_text())
        self.d=template
        self.d.update({'all_products_reviewed':True,'lower_fares_included':True,'screenshot_confirmation':True,'evidence_retained':True,'requires_policy_review':False})
        self.d['fares']=[{'name':'Delta Main Basic','status':'available','price':'250.00','currency':'USD','restrictions':'Synthetic restrictive fare','evidence_ids':['e1']},{'name':'Delta Main Classic','status':'available','price':'320.00','currency':'USD','restrictions':'Synthetic standard fare','evidence_ids':['e1']}]
        self.d['selected']={'product':'Delta Main Basic','price':'250.00'}
        self.sync()
    def tearDown(self): self.temp.cleanup()
    def sync(self):
        self.d['evidence']=[{'id':'e1','path':self.file.name,'sha256':self.digest,'captured_at':'2026-10-28T11:58:00-05:00','query':copy.deepcopy(self.d['query']),'kinds':['search','settings','availability','selected','restrictions'],'visually_verified':True,'reviewer':'SYNTHETIC TEST ASSERTION ONLY','selected':copy.deepcopy(self.d['selected']),'observations':{f['name']:{k:f[k] for k in ('status','price','currency','restrictions')} for f in self.d['fares']}}]
    def result(self): return audit(self.d,self.base)
    def test_01_delta_main_basic_available_selected(self):
        r=self.result();self.assertEqual(r['classification'],'Evidence complete');self.assertEqual(r['readiness'],'5/5');self.assertFalse(r['purchase_permission'])
    def test_02_delta_main_basic_explicitly_sold_out(self):
        self.d['fares'][0].update(status='sold_out',price=None)
        self.d['selected']={'product':'Delta Main Classic','price':'320.00'};self.sync()
        r=self.result();self.assertEqual(r['classification'],'Evidence complete');self.assertEqual(r['lowest_available_products'],['Delta Main Classic'])
    def test_03_delta_main_basic_absent(self):
        self.d['fares'][0].update(status='absent',price=None)
        self.d['selected']={'product':'Delta Main Classic','price':'320.00'};self.sync()
        r=self.result();self.assertEqual(r['classification'],'Evidence incomplete');self.assertTrue(r['policy_review_required']);self.assertNotEqual(r['readiness'],'5/5')
    def test_04_other_carriers_lowest_explicitly_unavailable(self):
        for carrier,low,high in [('American','Basic Economy','Main Cabin'),('United','Basic Economy','Economy'),('Southwest','Basic','Choice')]:
            with self.subTest(carrier=carrier):
                self.d['query']['airline']=carrier
                self.d['fares'][0].update(name=low,status='unavailable',price=None)
                self.d['fares'][1]['name']=high;self.d['selected']={'product':high,'price':'320.00'};self.sync()
                self.assertEqual(self.result()['classification'],'Evidence complete')
    def test_05_higher_selected_despite_lower_available(self):
        self.d['selected']={'product':'Delta Main Classic','price':'320.00'};self.sync()
        r=self.result();self.assertEqual(r['classification'],'Policy review required');self.assertEqual(r['evidence_status'],'Evidence complete');self.assertEqual(r['readiness'],'5/5');self.assertTrue(r['policy_review_required'])
    def test_06_completed_trip_missing_contemporaneous_evidence(self):
        self.d.update(phase='reimbursement',booked_at='2026-09-01T12:00:00-05:00',purchased={'product':'Delta Main Classic','price':'320.00','currency':'USD'},evidence=[])
        r=self.result();self.assertEqual(r['classification'],'Evidence incomplete');self.assertTrue(r['potential_upgrade_treatment']);self.assertIsNone(r['potential_reimbursement_difference']);self.assertEqual(r['traveler_paid'],'320.00')
    def test_query_mismatches_fail_closed(self):
        for key,value in [('travelers',2),('departure_date','2026-11-11'),('cabin','Business'),('fare_filters',{'include_basic':False}),('booking_source','https://other.example'),('currency','EUR')]:
            with self.subTest(key=key):
                self.sync();self.d['evidence'][0]['query'][key]=value
                self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_return_leg_mismatch_fails(self):
        q=self.d['query'];q['return_date']='2026-11-13'
        q['segments'].append({'marketing_carrier':'DL','operating_carrier':'DL','flight_number':'TEST-RETURN','origin':'DCA','destination':'HSV','departure':'2026-11-13T17:00:00-05:00','arrival':'2026-11-13T18:00:00-06:00'})
        self.sync();self.d['evidence'][0]['query']['segments'][1]['flight_number']='OTHER'
        self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_price_mismatch_fails(self):
        self.d['evidence'][0]['selected']['price']='249.00';self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_original_integrity_and_presence(self):
        self.file.write_bytes(b'altered');self.assertEqual(self.result()['classification'],'Evidence incomplete')
        self.file.unlink();self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_text_disguised_as_screenshot_fails(self):
        self.file.write_text('not original media');self.d['evidence'][0]['sha256']=hashlib.sha256(self.file.read_bytes()).hexdigest()
        self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_missing_confirmation_not_ready(self):
        self.d['screenshot_confirmation']=False;self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_no_visual_review_not_ready(self):
        self.d['evidence'][0]['visually_verified']=False;self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_absence_of_lower_in_filters_not_ready(self):
        self.d['lower_fares_included']=False;self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_stale_and_future_capture_not_ready(self):
        for time in ['2026-10-27T11:58:00-05:00','2026-10-28T12:01:00-05:00']:
            self.d['evidence'][0]['captured_at']=time;self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_historical_current_screenshot_never_proves_old_fare(self):
        self.d.update(phase='reimbursement',booked_at='2026-09-01T12:00:00-05:00',purchased={'product':'Delta Main Basic','price':'250.00','currency':'USD'})
        self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_reliable_historical_difference_only(self):
        self.d.update(phase='reimbursement',booked_at='2026-10-28T12:00:00-05:00',purchased={'product':'Delta Main Classic','price':'320.00','currency':'USD'})
        self.d['selected']={'product':'Delta Main Classic','price':'320.00'};self.sync()
        self.d['documents']=[{'kind':k,'path':self.file.name,'sha256':self.digest} for k in ['booking_confirmation','payment_receipt']]
        self.d['reliable_comparison']={'amount':'250.00','currency':'USD','path':self.file.name,'sha256':self.digest,'basis':'SYNTHETIC accepted historical record','historical_basis_verified':False,'accepted_by_business_services':False}
        self.assertIsNone(self.result()['potential_reimbursement_difference'])
        self.d['reliable_comparison'].update(historical_basis_verified=True,accepted_by_business_services=True)
        self.assertEqual(self.result()['potential_reimbursement_difference'],'70.00')
    def test_invalid_money_fails(self):
        for bad in ['NaN','Infinity','-1',None,True]:
            self.d['selected']['price']=bad
            with self.assertRaises(ValueError): self.result()
    def test_required_approval_not_silently_cleared(self):
        self.d['approval_required']=True
        self.assertEqual(self.result()['classification'],'Evidence incomplete')
        self.d['documents']=[{'kind':'approval','path':self.file.name,'sha256':self.digest}]
        self.assertEqual(self.result()['classification'],'Policy review required')
    def test_unreviewed_selected_restrictions_not_ready(self):
        self.d['evidence'][0]['observations']['Delta Main Basic']['restrictions']='different'
        self.assertEqual(self.result()['classification'],'Evidence incomplete')
    def test_missing_flight_or_passenger_query_rejected(self):
        self.d['query']['segments']=[]
        with self.assertRaises(ValueError):self.result()
    def test_documented_not_offered_distinct_from_absent(self):
        self.d['fares'][0].update(status='not_offered',price=None);self.d['selected']={'product':'Delta Main Classic','price':'320.00'};self.sync()
        self.assertEqual(self.result()['classification'],'Evidence complete')
if __name__=='__main__':unittest.main()
