# UAH travel planning report — {{trip_name}}

## Executive recommendation
{{preferred itinerary; known total or partial estimate; policy issues; immediate next action}}

## A — Trip details
{{business purpose, event/venue address, agenda source, required local attendance times/timezones, origin, recommended travel window, business/personal days, hotel dates/nights, funding restrictions}}

## B — Policy and per diem
{{classification, dated rate table by locality and night, meals/incidentals treatment, UAH applicability and conflicts, source section/effective/verification dates}}

## C — Flights
{{three feasible itineraries when available; flight-comparison.csv; price basis, restrictions, bags, source/timestamp}}
{{exact reminder and screenshot-confirmation question; per-itinerary audit result and actual x/5 checklist; remaining gaps}}

## D — Hotels
{{five exact-stay available room options when available; hotel-comparison.csv; nightly benchmarks/bands, taxes/fees, venue access, cancellation, verified kitchenette details}}

## E — Ground transportation
{{HSV/BNA/BHM/ATL tradeoffs, transfers, mapped miles, parking, tolls, destination transit, time, evidence and restrictions}}

## F — Cost scenarios
{{A lowest feasible total cost; B best overall value; C convenient; cost-analysis.csv; full economic cost, UAH payments, traveler outlay, potentially reimbursable costs, approvals/personal portions, dollar deltas and unknowns}}

## G — Compliance
{{finding | Confirmed compliant / Potentially compliant, subject to approval / Needs additional evidence / Conflicts with verified policy / Unable to verify | source/section/effective date | trip applicability | action}}
{{Airfare evidence readiness is separate from compliance; no certification inferred from 5/5}}

## H — Kuali preparation
{{current vs authorized legacy process, field-map.csv, current observed fields, draft values, routing and lead-time verification, attachments, actual approval status and remaining actions}}

## I — Evidence inventory
{{evidence-inventory.csv; retained originals, paths, timestamps, URLs, gaps, payment status}}

## J — Recommendation
{{one clear choice, documented total/time tradeoffs, required decision; draft only until approved}}

## Personal preference and taxi check
Record each candidate’s stop count, minimum layover, local departure/arrival times, overnight status, full cost and door-to-door duration. Flag preference misses and hard-floor failures. For drives ≤7 hours one-way, document UAH authorization review. Ground budget: 2 home-airport + 2 destination-airport/hotel + 2 × attendance-days hotel/conference taxi rides; adjust to actual itinerary and avoid duplicates. Quotes, payment and eligibility remain separate.

## Registration and meals
Registration category/membership | deadline | fee | mandatory extras | included meals | payer/payment status | receipt. Separate optional costs. Show first/last travel day at 75% and full intervening days, with applicable provided-meal adjustments and incidentals counted once. Unknown costs remain TBD.

## Component selection and evidence stages
Flight/drive option selected by traveler: pending / option / date. Hotel AND room type selected: pending / choice / date. Selection is not university approval or booking permission. Detailed screenshot status per component: pending / captured / mismatch. Uber route estimates: source/time, product, direction, fare/range, screenshot, limitations. Show first-draft links before asking selection; no final readiness claim without evidence.
