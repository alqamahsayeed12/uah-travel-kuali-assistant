# Travel exception draft — {{topic}}

Governing policy: {{source, section, effective date, applicability; unresolved points}}

Factual timeline: {{dated events and original evidence}}

Business necessity: {{supported reason only}}

Alternatives: {{comparable dates/flights/passengers; actual availability; source timestamps}}

Financial comparison: {{supported totals, economic cost versus possible reimbursement, payer and personal portions; unknown amounts remain unknown}}

Requested determination: {{specific approval or reimbursement question for Business Services}}

Attachments: {{original evidence filenames}}

Status: Draft for traveler review; no approval or transmission implied.
