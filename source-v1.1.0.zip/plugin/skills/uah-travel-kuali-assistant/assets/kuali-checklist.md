# Kuali authorization and reimbursement preparation

- [ ] Verify current consolidated process or pre-October-1-approved authorization exception.
- [ ] Verify live university access, current form fields and training; separate test from production.
- [ ] Confirm business purpose, venue, event times, travel window and personal portions.
- [ ] Verify current lead time, sponsor restrictions, funding and approval routing.
- [ ] Attach agenda, itemized budget, flight/hotel comparisons, government benchmarks and mapped route.
- [ ] Run mandatory per-itinerary airfare audit; ask screenshot confirmation and show actual x/5.
- [ ] Resolve policy conflicts and required justifications/approvals.
- [ ] Map draft concepts to observed fields with field-map.csv; mark unknowns.
- [ ] For reimbursement, reconcile originals and actual payment, duplicates, holds and payer channels.
- [ ] Review entire draft and attachments with traveler; record remaining gaps.
- [ ] Obtain action-specific permission immediately before submission/certification/finalization.
- [ ] After an authorized action, retain actual confirmation and status; do not infer success.
