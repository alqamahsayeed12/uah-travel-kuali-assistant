# Pre-Booking Audit Checklist

Airfare documentation readiness

{{verified_count}}/5

- [ ] Lowest-cost fare class identified
- [ ] Lowest fare availability screenshot captured
- [ ] Selected fare and price screenshot captured
- [ ] Dates, flights, passengers and settings match
- [ ] Evidence retained with booking documentation

At verified 5/5 only, display:

Evidence checklist complete — subject to policy review where needed.

Status: {{Evidence complete | Evidence incomplete | Policy review required}}
Also show policy-review flags and missing evidence independently.

Have you captured and retained the lowest-fare availability and selected-fare/price screenshots for these exact dates, flights, passengers and search settings?

Before purchasing, capture the lowest-fare availability and selected-fare screenshots. UAH Business Services requires evidence from the time of booking, particularly when a higher fare class is selected.
