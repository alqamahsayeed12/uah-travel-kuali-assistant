# Private setup and use

Version 1.0.0, prepared October 28, 2026. This is a complete skill-source package, not an installed or registered Work skill. It contains no credentials or private trip receipts. Keep it private; do not publish/share it. Do not install without the user's explicit approval of the target and action.

## What is ready

The skill folder contains SKILL.md, UI metadata, the complete master specification, complete latest eight-rule specification, policy source/version records, operational references, reusable templates, deterministic Python helpers and tests. The separate plugin ZIP wraps the same skill under skills/uah-travel-kuali-assistant with a portable root plugin.json. The standalone ZIP is suitable for a supported folder-based skill importer/installer; a ZIP does not itself install or set workspace visibility.

## ChatGPT Work

Official guidance: https://learn.chatgpt.com/docs/build-skills, https://learn.chatgpt.com/docs/build-plugins and https://learn.chatgpt.com/docs/enterprise/skills. Workspace creation and installation are separate from local filesystem skills. After the user approves installation, inspect the current Work Skills/Plugins interface and supported import/create flow. If workspace Plugin Creator is enabled, supply this package and request a private skill-only plugin preserving all files. Review the full name, instructions and resources, confirm Only me/private visibility, then approve installation separately if prompted. Keep connector access optional; no custom MCP server, credential or new account is required by this package. Do not claim that a generic ZIP-upload flow exists if the host does not offer one.

The present session exposes no workspace Skill/Plugin create-register tool. Work registration and visibility have not been performed or tested. Creating files here does not make the skill appear in the Work @ menu. The installed host must provide browsing, file inspection and optional Python execution to run those parts. Live Kuali requires authorized university access; the skill never bypasses sign-in. Test one synthetic case after installation before relying on real travel.

## Optional local Codex installation, only after approval

Copy the whole uah-travel-kuali-assistant folder into the user's supported per-user skills directory (normally ~/.codex/skills/) using the authorized installer. Do not overwrite an existing version without review. This package intentionally does not perform that copy. Local installation does not register a ChatGPT workspace skill or establish private workspace ownership. Retain the previous version for historical claims.

## Invocation

After successful registration, select the display name in Work's @ menu when offered, or invoke `$uah-travel-kuali-assistant` in Codex. Without installation, ask an agent with filesystem access to read this folder's SKILL.md and follow it for one task.

Examples:

- Plan HSV–San Francisco, November 2–6, 2026, at my supplied meeting venue. Compare three flights, five hotels within nightly benchmark ±$50, total trip cost and Kuali evidence.
- Compare HSV/BNA/BHM/ATL airfare for my exact event dates. Audit lower-fare availability before recommending documentation readiness.
- Find five exact-stay hotels near this conference; verify usable cooktops, cancellation deadlines and total stay plus transit.
- Prepare my Kuali draft from the selected options; identify missing documents and leave submission for approval.
- Review my completed drive-versus-fly trip. Use retained original comparison evidence or label a new comparison retrospective.
- Reconcile these receipts against authorization; separate P-Card and traveler payments and flag missing booking-time screenshots.

Run tests with `python3 -m unittest discover -s tests -v`. Use references/script-guide.md for inputs/exit codes. Synthetic tests demonstrate deterministic logic; authenticated Kuali, live inventory, true screenshot provenance, workspace installation and real reimbursement outcomes remain unverified.

## User-designated documentation root

All travel documentation belongs under `$HOME/UAH_Travel` (`$HOME/UAH_Travel`). Use `trips/YYYY-MM-DD_Destination_TripName/` for each trip and `airfare-evidence/` within it. Reusable skill copies stay separate from confidential trip records. This location is explicitly requested by the user; no restricted documents are uploaded or shared by choosing it.
