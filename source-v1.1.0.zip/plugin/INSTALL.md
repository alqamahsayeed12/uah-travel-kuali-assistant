# Private plugin package

Contains the identical complete skill under skills/uah-travel-kuali-assistant and portable root plugin.json, following https://developers.openai.com/plugins/build/plugins . No custom server, app connection, hook, secret or executable installer is bundled.

Read skills/uah-travel-kuali-assistant/INSTALL.md for setup, invocation and limitations. Do not publish, share or install without explicit user approval. A manifest does not establish workspace visibility or install itself. Work registration/private visibility have not been performed or verified. Validate acceptance in the target host after approved installation; no schema field here pretends to enforce privacy.
