from pathlib import Path
import hashlib, subprocess, sys, zipfile
root=Path(__file__).resolve().parents[1]
skill=root/'plugin/skills/uah-travel-kuali-assistant'
subprocess.run([sys.executable,'-m','unittest','discover','-s',str(skill/'tests'),'-v'],check=True)
subprocess.run([sys.executable,str(skill/'scripts/validate_package.py'),str(skill)],check=True)
out=root/'dist';out.mkdir(exist_ok=True)
for folder,name in [(root/'plugin','uah-travel-kuali-plugin.zip'),(skill,'uah-travel-kuali-skill.zip')]:
    with zipfile.ZipFile(out/name,'w',compression=zipfile.ZIP_STORED) as z:
        for p in sorted(folder.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
            info=zipfile.ZipInfo(p.relative_to(folder).as_posix(),(2026,1,1,0,0,0));info.external_attr=0o100644<<16
            z.writestr(info,p.read_bytes())
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(out.glob('*.zip'))))
print('Tests passed; reproducible packages written to dist/')
